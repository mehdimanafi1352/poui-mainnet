//! Experimental proof-of-useful-computation consensus candidate.
//!
//! Work is dense matrix multiplication on a parent/height/nonce-derived challenge.
//! The verifier uses deterministic Freivalds checks and a hash-target gate. This is
//! an engineering candidate, NOT a reviewed consensus algorithm or mainnet-ready PoUI.

pub mod chain_rules;
use poui_protocol_core::Hash32;
use serde::{Deserialize, Serialize};
use sha3::{Digest, Sha3_256};
use thiserror::Error;

pub const TASK_DIMENSION: usize = 24;
const PRIME: i64 = 2_147_483_647;
const MAX_DIFFICULTY_BITS: u8 = 24;

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct MatrixWorkProof {
    pub version: u16,
    pub height: u64,
    pub nonce: u64,
    pub dimension: u16,
    /// Row-major exact integer product A × B; canonical signed little-endian values in serde encoding.
    pub product: Vec<i64>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct VerifiedWork {
    pub work_hash: Hash32,
    pub score: u64,
}

#[derive(Debug, Error, Eq, PartialEq)]
pub enum WorkError {
    #[error("unsupported proof version")]
    Version,
    #[error("proof height does not match candidate block height")]
    Height,
    #[error("unsupported matrix dimension")]
    Dimension,
    #[error("product has wrong number of entries")]
    ProductLength,
    #[error("matrix multiplication proof failed verification")]
    InvalidProduct,
    #[error("difficulty must be between 0 and 24 bits")]
    Difficulty,
    #[error("proof does not meet the target")]
    InsufficientWork,
}

fn digest(parts: &[&[u8]]) -> Hash32 {
    let mut h = Sha3_256::new();
    for part in parts { h.update((part.len() as u64).to_le_bytes()); h.update(part); }
    let out = h.finalize();
    let mut b = [0u8; 32]; b.copy_from_slice(&out); Hash32(b)
}

fn seed_for(parent: Hash32, height: u64, nonce: u64, label: &[u8]) -> Hash32 {
    digest(&[b"POUI-MATRIX-TASK-v1", &parent.0, &height.to_le_bytes(), &nonce.to_le_bytes(), label])
}

fn matrix(seed: Hash32, n: usize) -> Vec<i64> {
    let mut out = Vec::with_capacity(n*n);
    let mut counter = 0u64;
    while out.len() < n*n {
        let block = digest(&[b"POUI-MATRIX-EXPAND-v1", &seed.0, &counter.to_le_bytes()]);
        for byte in block.0 {
            if out.len() == n*n { break; }
            out.push((byte & 0x0f) as i64);
        }
        counter += 1;
    }
    out
}

fn matrices(parent: Hash32, height: u64, nonce: u64, n: usize) -> (Vec<i64>, Vec<i64>) {
    (matrix(seed_for(parent, height, nonce, b"A"), n), matrix(seed_for(parent, height, nonce, b"B"), n))
}

fn multiply(a: &[i64], b: &[i64], n: usize) -> Vec<i64> {
    let mut c = vec![0i64; n*n];
    for i in 0..n { for k in 0..n { let aik = a[i*n+k]; for j in 0..n { c[i*n+j] += aik*b[k*n+j]; } } }
    c
}

fn product_hash(parent: Hash32, proof: &MatrixWorkProof) -> Hash32 {
    let mut bytes = Vec::with_capacity(proof.product.len()*8);
    for x in &proof.product { bytes.extend_from_slice(&x.to_le_bytes()); }
    digest(&[b"POUI-PRODUCT-v1", &parent.0, &proof.height.to_le_bytes(), &proof.nonce.to_le_bytes(), &bytes])
}

fn work_hash(parent: Hash32, proof: &MatrixWorkProof) -> Hash32 {
    let p = product_hash(parent, proof);
    digest(&[b"POUI-WORK-SCORE-v1", &parent.0, &proof.height.to_le_bytes(), &proof.nonce.to_le_bytes(), &p.0])
}

fn has_leading_zero_bits(hash: Hash32, bits: u8) -> bool {
    let full = (bits / 8) as usize;
    let rem = bits % 8;
    if hash.0[..full].iter().any(|b| *b != 0) { return false; }
    rem == 0 || (hash.0[full] >> (8-rem)) == 0
}

fn verify_freivalds(parent: Hash32, proof: &MatrixWorkProof, commitment: Hash32, a: &[i64], b: &[i64], n: usize) -> bool {
    // Fiat-Shamir-style challenge binds the random vectors to the committed product.
    // This probabilistic check still requires formal cryptographic review.
    for round in 0..2u8 {
        let vseed = digest(&[b"POUI-FREIVALDS-v1", &parent.0, &proof.height.to_le_bytes(), &proof.nonce.to_le_bytes(), &commitment.0, &[round]]);
        let mut v = Vec::with_capacity(n);
        for i in 0..n {
            let block = digest(&[b"POUI-FREIVALDS-VECTOR-v1", &vseed.0, &(i as u64).to_le_bytes()]);
            v.push((u32::from_le_bytes([block.0[0],block.0[1],block.0[2],block.0[3]]) as i64) % PRIME);
        }
        let mut bv = vec![0i64; n];
        let mut abv = vec![0i64; n];
        let mut cv = vec![0i64; n];
        for i in 0..n { for j in 0..n { bv[i] = (bv[i] + (b[i*n+j] * v[j]) % PRIME) % PRIME; } }
        for i in 0..n { for j in 0..n { abv[i] = (abv[i] + (a[i*n+j] * bv[j]) % PRIME) % PRIME; } }
        for i in 0..n { for j in 0..n { cv[i] = (cv[i] + ((proof.product[i*n+j] % PRIME) * v[j]) % PRIME) % PRIME; } }
        if abv != cv { return false; }
    }
    true
}

/// Solve one task instance. CPU-intensive work is the matrix product; the nonce is
/// varied by the miner to meet the target. `dimension` is protocol-fixed in v1.
pub fn solve(parent: Hash32, height: u64, nonce: u64) -> MatrixWorkProof {
    let n = TASK_DIMENSION;
    let (a,b) = matrices(parent, height, nonce, n);
    MatrixWorkProof { version: 1, height, nonce, dimension: n as u16, product: multiply(&a,&b,n) }
}

/// Verify task correctness and target. Every consensus node must run this function.
pub fn verify(parent: Hash32, expected_height: u64, proof: &MatrixWorkProof, difficulty_bits: u8) -> Result<VerifiedWork, WorkError> {
    if proof.version != 1 { return Err(WorkError::Version); }
    if proof.height != expected_height { return Err(WorkError::Height); }
    if proof.dimension as usize != TASK_DIMENSION { return Err(WorkError::Dimension); }
    if proof.product.len() != TASK_DIMENSION*TASK_DIMENSION { return Err(WorkError::ProductLength); }
    if difficulty_bits > MAX_DIFFICULTY_BITS { return Err(WorkError::Difficulty); }
    let (a,b) = matrices(parent, expected_height, proof.nonce, TASK_DIMENSION);
    let commitment = product_hash(parent, proof);
    if !verify_freivalds(parent, proof, commitment, &a, &b, TASK_DIMENSION) { return Err(WorkError::InvalidProduct); }
    // Bound values so malformed proofs cannot exploit modular arithmetic ambiguities.
    if proof.product.iter().any(|x| !(0..=TASK_DIMENSION as i64 * 225).contains(x)) { return Err(WorkError::InvalidProduct); }
    let score_hash = work_hash(parent, proof);
    if !has_leading_zero_bits(score_hash, difficulty_bits) { return Err(WorkError::InsufficientWork); }
    Ok(VerifiedWork { work_hash: score_hash, score: 1u64 << difficulty_bits })
}

pub fn mine(parent: Hash32, height: u64, start_nonce: u64, max_attempts: u64, difficulty_bits: u8) -> Result<Option<MatrixWorkProof>, WorkError> {
    if difficulty_bits > MAX_DIFFICULTY_BITS { return Err(WorkError::Difficulty); }
    for offset in 0..max_attempts {
        let Some(nonce) = start_nonce.checked_add(offset) else { break };
        let proof = solve(parent, height, nonce);
        if has_leading_zero_bits(work_hash(parent, &proof), difficulty_bits) {
            return Ok(Some(proof));
        }
    }
    Ok(None)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn solved_proof_verifies_at_zero_difficulty() {
        let parent = Hash32::digest(b"test parent");
        let proof = solve(parent, 1, 7);
        assert!(verify(parent, 1, &proof, 0).is_ok());
    }
    #[test]
    fn tampered_product_is_rejected() {
        let parent = Hash32::digest(b"test parent");
        let mut proof = solve(parent, 1, 7);
        proof.product[0] += 1;
        assert!(verify(parent, 1, &proof, 0).is_err());
    }
    #[test]
    fn wrong_height_is_rejected() {
        let parent = Hash32::digest(b"test parent");
        let proof = solve(parent, 1, 7);
        assert_eq!(verify(parent, 2, &proof, 0), Err(WorkError::Height));
    }
    #[test]
    fn mining_finds_a_valid_easy_proof() {
        let parent = Hash32::digest(b"miner test");
        let proof = mine(parent, 3, 0, 100, 4).unwrap().unwrap();
        assert!(verify(parent, 3, &proof, 4).is_ok());
    }
}
