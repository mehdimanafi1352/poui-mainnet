//! Persistent single-node chain store with deterministic block/proof validation.
//! Networking, transaction semantics, state transitions and privacy are not implemented here.
use poui_consensus::{verify, MatrixWorkProof};
use poui_protocol_core::{validate_block_structure, Block, Hash32, ParentContext, ProtocolError};
use serde::{Deserialize, Serialize};
use std::{fs::{File, OpenOptions}, io::{Read, Seek, SeekFrom, Write}, path::{Path, PathBuf}};
use thiserror::Error;

const MAX_RECORD_BYTES: usize = 2_000_000;
const RECORD_PREFIX_BYTES: usize = 4;

#[derive(Clone, Debug)]
pub struct NodeConfig {
    pub chain_id: String,
    pub genesis_timestamp: u64,
    /// Fixed until the retarget rule is wired into block headers and validation.
    pub difficulty_bits: u8,
}

#[derive(Debug, Error)]
pub enum StoreError {
    #[error("I/O error: {0}")]
    Io(#[from] std::io::Error),
    #[error("serialization error: {0}")]
    Encoding(String),
    #[error("invalid block structure: {0}")]
    Block(#[from] ProtocolError),
    #[error("invalid PoUI proof encoding: {0}")]
    ProofEncoding(String),
    #[error("PoUI proof rejected: {0}")]
    Proof(String),
    #[error("difficulty configuration must be <= 24 bits")]
    Difficulty,
    #[error("record length is invalid or exceeds the configured maximum")]
    RecordLength,
    #[error("truncated/corrupt chain record at byte offset {0}")]
    CorruptRecord(u64),
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct ChainTip {
    pub height: u64,
    pub hash: Hash32,
    pub timestamp: u64,
    pub cumulative_work: u128,
}

pub struct ChainStore {
    path: PathBuf,
    file: File,
    config: NodeConfig,
    blocks: Vec<Block>,
    tip: ChainTip,
}

impl ChainStore {
    pub fn open(path: impl AsRef<Path>, config: NodeConfig) -> Result<Self, StoreError> {
        if config.difficulty_bits > 24 { return Err(StoreError::Difficulty); }
        let path = path.as_ref().to_path_buf();
        if let Some(parent) = path.parent() { std::fs::create_dir_all(parent)?; }
        let mut file = OpenOptions::new().create(true).read(true).write(true).open(&path)?;
        let mut blocks = Vec::new();
        let mut offset = 0u64;
        let file_len = file.metadata()?.len();
        let mut tip = ChainTip { height: 0, hash: Hash32::ZERO, timestamp: config.genesis_timestamp, cumulative_work: 0 };

        loop {
            file.seek(SeekFrom::Start(offset))?;
            let mut prefix = [0u8; RECORD_PREFIX_BYTES];
            let got = read_partial(&mut file, &mut prefix)?;
            if got == 0 { break; }
            if got != RECORD_PREFIX_BYTES {
                if offset + got as u64 == file_len { file.set_len(offset)?; break; }
                return Err(StoreError::CorruptRecord(offset));
            }
            let len = u32::from_le_bytes(prefix) as usize;
            if len == 0 || len > MAX_RECORD_BYTES { return Err(StoreError::RecordLength); }
            let mut bytes = vec![0u8; len];
            if read_partial(&mut file, &mut bytes)? != len {
                file.set_len(offset)?;
                break;
            }
            let block: Block = bincode::deserialize(&bytes).map_err(|e| StoreError::Encoding(e.to_string()))?;
            validate_candidate(&block, &config, &tip)?;
            let block_hash = block.hash().map_err(|e| StoreError::Encoding(e.to_string()))?;
            tip = ChainTip {
                height: block.header.height,
                hash: block_hash,
                timestamp: block.header.timestamp,
                cumulative_work: tip.cumulative_work.checked_add(1u128 << config.difficulty_bits).ok_or(StoreError::Difficulty)?,
            };
            blocks.push(block);
            offset = offset.checked_add(RECORD_PREFIX_BYTES as u64 + len as u64).ok_or(StoreError::RecordLength)?;
        }
        file.seek(SeekFrom::End(0))?;
        Ok(Self { path, file, config, blocks, tip })
    }

    pub fn tip(&self) -> &ChainTip { &self.tip }
    pub fn len(&self) -> usize { self.blocks.len() }
    pub fn is_empty(&self) -> bool { self.blocks.is_empty() }
    pub fn blocks(&self) -> &[Block] { &self.blocks }
    pub fn path(&self) -> &Path { &self.path }

    /// Validates the block and its proof before persisting it. Only the current tip may be extended.
    pub fn append(&mut self, block: Block) -> Result<Hash32, StoreError> {
        validate_candidate(&block, &self.config, &self.tip)?;
        let hash = block.hash().map_err(|e| StoreError::Encoding(e.to_string()))?;
        let bytes = bincode::serialize(&block).map_err(|e| StoreError::Encoding(e.to_string()))?;
        if bytes.is_empty() || bytes.len() > MAX_RECORD_BYTES || bytes.len() > u32::MAX as usize {
            return Err(StoreError::RecordLength);
        }
        self.file.seek(SeekFrom::End(0))?;
        self.file.write_all(&(bytes.len() as u32).to_le_bytes())?;
        self.file.write_all(&bytes)?;
        self.file.sync_all()?;
        self.tip = ChainTip {
            height: block.header.height,
            hash,
            timestamp: block.header.timestamp,
            cumulative_work: self.tip.cumulative_work.checked_add(1u128 << self.config.difficulty_bits).ok_or(StoreError::Difficulty)?,
        };
        self.blocks.push(block);
        Ok(hash)
    }

    pub fn get_by_height(&self, height: u64) -> Option<&Block> {
        if height == 0 { return None; }
        self.blocks.get((height - 1) as usize).filter(|b| b.header.height == height)
    }
}

fn read_partial<R: Read>(reader: &mut R, buf: &mut [u8]) -> Result<usize, std::io::Error> {
    let mut total = 0;
    while total < buf.len() {
        match reader.read(&mut buf[total..])? {
            0 => break,
            n => total += n,
        }
    }
    Ok(total)
}

fn validate_candidate(block: &Block, config: &NodeConfig, tip: &ChainTip) -> Result<(), StoreError> {
    let parent = ParentContext {
        chain_id: config.chain_id.clone(),
        height: tip.height,
        hash: tip.hash,
        timestamp: tip.timestamp,
    };
    validate_block_structure(block, &parent)?;
    let proof: MatrixWorkProof = serde_json::from_slice(&block.header.poui_proof)
        .map_err(|e| StoreError::ProofEncoding(e.to_string()))?;
    verify(tip.hash, block.header.height, &proof, config.difficulty_bits)
        .map_err(|e| StoreError::Proof(e.to_string()))?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use poui_consensus::solve;
    use poui_protocol_core::{BlockHeader, Transaction, PROTOCOL_VERSION};

    fn path(tag: &str) -> PathBuf {
        std::env::temp_dir().join(format!("poui-node-{}-{}.dat", std::process::id(), tag))
    }
    fn config() -> NodeConfig {
        NodeConfig { chain_id: "poui-mainnet-1".into(), genesis_timestamp: 100, difficulty_bits: 0 }
    }
    fn block(parent_hash: Hash32, height: u64, timestamp: u64) -> Block {
        let proof = solve(parent_hash, height, height + 7);
        let transactions = vec![Transaction::new(b"tx-body".to_vec())];
        Block { header: BlockHeader {
            protocol_version: PROTOCOL_VERSION,
            chain_id: "poui-mainnet-1".into(), height, parent_hash,
            tx_root: Block::transaction_root(&transactions), timestamp,
            poui_proof: serde_json::to_vec(&proof).unwrap(),
        }, transactions }
    }

    #[test]
    fn appends_and_recovers_chain_after_reopen() {
        let p = path("reopen"); let _ = std::fs::remove_file(&p);
        {
            let mut store = ChainStore::open(&p, config()).unwrap();
            let b = block(Hash32::ZERO, 1, 101);
            let hash = store.append(b).unwrap();
            assert_eq!(store.tip().hash, hash);
            assert_eq!(store.len(), 1);
        }
        {
            let store = ChainStore::open(&p, config()).unwrap();
            assert_eq!(store.tip().height, 1);
            assert_eq!(store.len(), 1);
            assert!(store.get_by_height(1).is_some());
        }
        let _ = std::fs::remove_file(p);
    }

    #[test]
    fn recovers_truncated_final_record() {
        let p = path("truncated-tail"); let _ = std::fs::remove_file(&p);
        {
            let mut store = ChainStore::open(&p, config()).unwrap();
            store.append(block(Hash32::ZERO, 1, 101)).unwrap();
        }
        {
            let mut file = OpenOptions::new().append(true).open(&p).unwrap();
            file.write_all(&[0x10, 0x00]).unwrap();
            file.sync_all().unwrap();
        }
        {
            let store = ChainStore::open(&p, config()).unwrap();
            assert_eq!(store.tip().height, 1);
            assert_eq!(store.len(), 1);
        }
        let _ = std::fs::remove_file(p);
    }

    #[test]
    fn rejects_wrong_parent_without_persisting() {
        let p = path("parent"); let _ = std::fs::remove_file(&p);
        let mut store = ChainStore::open(&p, config()).unwrap();
        let b = block(Hash32::digest(b"not genesis"), 1, 101);
        assert!(store.append(b).is_err());
        assert!(store.is_empty());
        let _ = std::fs::remove_file(p);
    }

    #[test]
    fn rejects_tampered_work_proof() {
        let p = path("proof"); let _ = std::fs::remove_file(&p);
        let mut store = ChainStore::open(&p, config()).unwrap();
        let mut b = block(Hash32::ZERO, 1, 101);
        let mut proof: MatrixWorkProof = serde_json::from_slice(&b.header.poui_proof).unwrap();
        proof.product[0] += 1;
        b.header.poui_proof = serde_json::to_vec(&proof).unwrap();
        assert!(store.append(b).is_err());
        assert!(store.is_empty());
        let _ = std::fs::remove_file(p);
    }
}
