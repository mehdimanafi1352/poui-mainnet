//! Deterministic chain selection and bounded difficulty retarget rules.
//! These rules are an implementation candidate and require adversarial review.
use poui_protocol_core::Hash32;
use thiserror::Error;

pub const MAX_DIFFICULTY_BITS: u8 = 24;
pub const MIN_DIFFICULTY_BITS: u8 = 1;

#[derive(Debug, Error, Clone, Eq, PartialEq)]
pub enum RuleError {
    #[error("target block interval must be non-zero")]
    ZeroTargetInterval,
    #[error("retarget window must contain at least one interval")]
    ZeroWindow,
    #[error("cumulative work overflow")]
    WorkOverflow,
}

/// Retarget at a fixed window boundary. `elapsed_seconds` must be the timestamp
/// difference between the two protocol-defined window endpoints. The caller must
/// use the same endpoints on every node. Adjustment is bounded to one bit per window.
pub fn retarget_difficulty(
    current_bits: u8,
    elapsed_seconds: u64,
    target_interval_seconds: u64,
    window_blocks: u64,
) -> Result<u8, RuleError> {
    if target_interval_seconds == 0 { return Err(RuleError::ZeroTargetInterval); }
    if window_blocks == 0 { return Err(RuleError::ZeroWindow); }
    let target = target_interval_seconds.saturating_mul(window_blocks);
    let elapsed = elapsed_seconds.max(1);
    let bounded = current_bits.clamp(MIN_DIFFICULTY_BITS, MAX_DIFFICULTY_BITS);
    if elapsed.saturating_mul(2) < target {
        Ok(bounded.saturating_add(1).min(MAX_DIFFICULTY_BITS))
    } else if elapsed > target.saturating_mul(2) {
        Ok(bounded.saturating_sub(1).max(MIN_DIFFICULTY_BITS))
    } else {
        Ok(bounded)
    }
}

/// A branch's cumulative expected work. Each accepted block contributes 2^difficulty_bits.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct ChainWeight {
    pub cumulative_work: u128,
    pub tip_hash: Hash32,
}

impl ChainWeight {
    pub fn append(self, difficulty_bits: u8, new_tip_hash: Hash32) -> Result<Self, RuleError> {
        if difficulty_bits > MAX_DIFFICULTY_BITS { return Err(RuleError::WorkOverflow); }
        let work = 1u128.checked_shl(difficulty_bits as u32).ok_or(RuleError::WorkOverflow)?;
        let cumulative_work = self.cumulative_work.checked_add(work).ok_or(RuleError::WorkOverflow)?;
        Ok(Self { cumulative_work, tip_hash: new_tip_hash })
    }
}

/// Returns true if `candidate` wins fork choice. More cumulative work wins; exact
/// ties resolve to the lexicographically smaller tip hash, independent of arrival order.
pub fn candidate_wins(candidate: ChainWeight, incumbent: ChainWeight) -> bool {
    candidate.cumulative_work > incumbent.cumulative_work
        || (candidate.cumulative_work == incumbent.cumulative_work
            && candidate.tip_hash.0 < incumbent.tip_hash.0)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn hash(byte: u8) -> Hash32 { Hash32([byte; 32]) }

    #[test]
    fn difficulty_rises_when_blocks_are_too_fast() {
        assert_eq!(retarget_difficulty(8, 200, 60, 10), Ok(9));
    }

    #[test]
    fn difficulty_falls_when_blocks_are_too_slow() {
        assert_eq!(retarget_difficulty(8, 1300, 60, 10), Ok(7));
    }

    #[test]
    fn difficulty_stays_inside_deadband() {
        assert_eq!(retarget_difficulty(8, 600, 60, 10), Ok(8));
    }

    #[test]
    fn difficulty_is_clamped() {
        assert_eq!(retarget_difficulty(24, 1, 60, 10), Ok(24));
        assert_eq!(retarget_difficulty(1, u64::MAX, 60, 10), Ok(1));
    }

    #[test]
    fn fork_choice_prefers_more_work() {
        let low = ChainWeight { cumulative_work: 100, tip_hash: hash(1) };
        let high = ChainWeight { cumulative_work: 101, tip_hash: hash(255) };
        assert!(candidate_wins(high, low));
        assert!(!candidate_wins(low, high));
    }

    #[test]
    fn fork_choice_tie_break_is_deterministic() {
        let a = ChainWeight { cumulative_work: 100, tip_hash: hash(1) };
        let b = ChainWeight { cumulative_work: 100, tip_hash: hash(2) };
        assert!(candidate_wins(a, b));
        assert!(!candidate_wins(b, a));
    }

    #[test]
    fn rejects_zero_parameters() {
        assert_eq!(retarget_difficulty(8, 100, 0, 10), Err(RuleError::ZeroTargetInterval));
        assert_eq!(retarget_difficulty(8, 100, 60, 0), Err(RuleError::ZeroWindow));
    }
}
