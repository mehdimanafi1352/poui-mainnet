# PoUI node CLI (experimental)

This binary integrates the current experimental chain store, matrix-work candidate, and a small TCP request/response protocol.

Commands:

```text
poui-node init --data data/chain.dat --difficulty-bits 4
poui-node status --data data/chain.dat --difficulty-bits 4
poui-node mine --data data/chain.dat --difficulty-bits 4 --max-attempts 10000
poui-node serve --data data/chain.dat --difficulty-bits 4 --bind 127.0.0.1:7070
poui-node sync --data data/peer-copy.dat --difficulty-bits 4 --peer 127.0.0.1:7070
poui-node export --data data/chain.dat --difficulty-bits 4 --out chain.json
```

The difficulty setting must be identical across nodes and is currently a local configuration value, not committed into block headers. The protocol is experimental; this TCP protocol is unauthenticated and not hardened against hostile peers. Sync only extends the current local tip and does not implement reorganization or full fork-choice. Do not expose it to the public Internet or call it mainnet-ready.
