//! Deterministic protocol primitives for the PoUI chain.
//! This crate does not claim mainnet readiness or implement private transactions yet.
use serde::{Deserialize, Serialize};
use sha3::{Digest, Sha3_256};
use thiserror::Error;

pub const PROTOCOL_VERSION: u16 = 1;
pub const MAX_TXS_PER_BLOCK: usize = 10_000;
pub const MAX_BLOCK_BYTES: usize = 2_000_000;

#[derive(Clone, Copy, Debug, Eq, PartialEq, Hash, Serialize, Deserialize)]
pub struct Hash32(pub [u8; 32]);

impl Hash32 {
    pub const ZERO: Self = Self([0u8; 32]);
    pub fn digest(bytes: &[u8]) -> Self {
        let out = Sha3_256::digest(bytes);
        let mut value = [0u8; 32];
        value.copy_from_slice(&out);
        Self(value)
    }
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct Transaction {
    /// Canonical transaction identifier; checked against the serialized body.
    pub id: Hash32,
    /// Canonical transaction bytes. Transaction semantics are validated by a future
    /// transaction module; this core at least rejects identifier/body mismatches.
    pub body: Vec<u8>,
}

impl Transaction {
    pub fn new(body: Vec<u8>) -> Self {
        let id = Hash32::digest(&body);
        Self { id, body }
    }
    pub fn verify_id(&self) -> bool { self.id == Hash32::digest(&self.body) }
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct BlockHeader {
    pub protocol_version: u16,
    pub chain_id: String,
    pub height: u64,
    pub parent_hash: Hash32,
    pub tx_root: Hash32,
    pub timestamp: u64,
    /// Encoded PoUI proof bytes. Empty proof is rejected; the actual PoUI verifier
    /// must be installed by the consensus crate before a network can launch.
    pub poui_proof: Vec<u8>,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct Block {
    pub header: BlockHeader,
    pub transactions: Vec<Transaction>,
}

impl Block {
    pub fn transaction_root(txs: &[Transaction]) -> Hash32 {
        let mut bytes = Vec::with_capacity(txs.len() * 32);
        for tx in txs { bytes.extend_from_slice(&tx.id.0); }
        Hash32::digest(&bytes)
    }

    pub fn hash(&self) -> Result<Hash32, ProtocolError> {
        let encoded = bincode::serialize(&self.header)
            .map_err(|e| ProtocolError::Encoding(e.to_string()))?;
        Ok(Hash32::digest(&encoded))
    }

    pub fn encoded_size(&self) -> Result<usize, ProtocolError> {
        bincode::serialized_size(self)
            .map(|n| n as usize)
            .map_err(|e| ProtocolError::Encoding(e.to_string()))
    }
}

#[derive(Clone, Debug)]
pub struct ParentContext {
    pub chain_id: String,
    pub height: u64,
    pub hash: Hash32,
    pub timestamp: u64,
}

#[derive(Debug, Error, Eq, PartialEq)]
pub enum ProtocolError {
    #[error("wrong protocol version")]
    WrongVersion,
    #[error("wrong chain id")]
    WrongChain,
    #[error("invalid block height")]
    WrongHeight,
    #[error("parent hash mismatch")]
    WrongParent,
    #[error("timestamp is not strictly greater than parent timestamp")]
    InvalidTimestamp,
    #[error("block has too many transactions")]
    TooManyTransactions,
    #[error("block exceeds maximum encoded size")]
    BlockTooLarge,
    #[error("transaction identifier does not match body")]
    InvalidTransactionId,
    #[error("transaction root mismatch")]
    WrongTransactionRoot,
    #[error("missing PoUI proof")]
    MissingProof,
    #[error("encoding error: {0}")]
    Encoding(String),
}

/// Structural checks only. Consensus must additionally verify proof-of-useful-work,
/// transaction rules, state transition, issuance, and fork-choice before accepting.
pub fn validate_block_structure(block: &Block, parent: &ParentContext) -> Result<(), ProtocolError> {
    if block.header.protocol_version != PROTOCOL_VERSION { return Err(ProtocolError::WrongVersion); }
    if block.header.chain_id != parent.chain_id { return Err(ProtocolError::WrongChain); }
    if parent.height.checked_add(1) != Some(block.header.height) { return Err(ProtocolError::WrongHeight); }
    if block.header.parent_hash != parent.hash { return Err(ProtocolError::WrongParent); }
    if block.header.timestamp <= parent.timestamp { return Err(ProtocolError::InvalidTimestamp); }
    if block.transactions.len() > MAX_TXS_PER_BLOCK { return Err(ProtocolError::TooManyTransactions); }
    if block.header.poui_proof.is_empty() { return Err(ProtocolError::MissingProof); }
    for tx in &block.transactions {
        if !tx.verify_id() { return Err(ProtocolError::InvalidTransactionId); }
    }
    if Block::transaction_root(&block.transactions) != block.header.tx_root {
        return Err(ProtocolError::WrongTransactionRoot);
    }
    if block.encoded_size()? > MAX_BLOCK_BYTES { return Err(ProtocolError::BlockTooLarge); }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    fn sample_block(parent: &ParentContext) -> Block {
        let transactions = vec![Transaction::new(b"sample transaction".to_vec())];
        let tx_root = Block::transaction_root(&transactions);
        Block { header: BlockHeader {
            protocol_version: PROTOCOL_VERSION,
            chain_id: parent.chain_id.clone(),
            height: parent.height + 1,
            parent_hash: parent.hash,
            tx_root,
            timestamp: parent.timestamp + 1,
            poui_proof: vec![1],
        }, transactions }
    }

    #[test]
    fn accepts_structurally_valid_block() {
        let parent = ParentContext { chain_id: "poui-mainnet-1".into(), height: 0,
            hash: Hash32::ZERO, timestamp: 100 };
        assert_eq!(validate_block_structure(&sample_block(&parent), &parent), Ok(()));
    }

    #[test]
    fn rejects_wrong_parent() {
        let parent = ParentContext { chain_id: "poui-mainnet-1".into(), height: 0,
            hash: Hash32::ZERO, timestamp: 100 };
        let mut block = sample_block(&parent);
        block.header.parent_hash = Hash32::digest(b"wrong parent");
        assert_eq!(validate_block_structure(&block, &parent), Err(ProtocolError::WrongParent));
    }

    #[test]
    fn rejects_transaction_body_tampering() {
        let parent = ParentContext { chain_id: "poui-mainnet-1".into(), height: 0,
            hash: Hash32::ZERO, timestamp: 100 };
        let mut block = sample_block(&parent);
        block.transactions[0].body.push(0);
        assert_eq!(validate_block_structure(&block, &parent), Err(ProtocolError::InvalidTransactionId));
    }

    #[test]
    fn rejects_missing_proof() {
        let parent = ParentContext { chain_id: "poui-mainnet-1".into(), height: 0,
            hash: Hash32::ZERO, timestamp: 100 };
        let mut block = sample_block(&parent);
        block.header.poui_proof.clear();
        assert_eq!(validate_block_structure(&block, &parent), Err(ProtocolError::MissingProof));
    }
}
